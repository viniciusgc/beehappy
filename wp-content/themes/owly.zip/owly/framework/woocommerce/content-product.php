<?php

// Add required files

require_once( OWLY_THEME_DIR .'/framework/woocommerce/content-product/utils.php' ); // Util functions
require_once( OWLY_THEME_DIR .'/framework/woocommerce/content-product/sorter.php' ); // Sorter - Header & Footer
require_once( OWLY_THEME_DIR .'/framework/woocommerce/content-product/loop-start-end.php' ); // Product Loop - Start & End
require_once( OWLY_THEME_DIR .'/framework/woocommerce/content-product/content-utils.php' ); // Product Content Utils
require_once( OWLY_THEME_DIR .'/framework/woocommerce/content-product/content-thumb.php' ); // Product Content Thumb
require_once( OWLY_THEME_DIR .'/framework/woocommerce/content-product/content-content.php' ); // Product Content Content

?>