<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

	<div class="entry-body"><?php echo owly_excerpt( $excerpt_length );?></div>